package ds.gae.view;

import java.text.SimpleDateFormat;

public final class Tools {
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd.MM.yyyy");
}
